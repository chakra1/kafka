package com.baeldung.flink.operator;

import com.baeldung.flink.model.Backup;
import com.baeldung.flink.model.InputIoTMessage;
import com.baeldung.flink.model.InputMessage;
import org.apache.flink.api.common.functions.AggregateFunction;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AverageAggregator implements AggregateFunction<InputIoTMessage, List<InputIoTMessage>, Double> {

	@Override
	public List<InputIoTMessage> createAccumulator() {
		return new ArrayList<>();
	}

	@Override
	public List<InputIoTMessage> add(InputIoTMessage value, List<InputIoTMessage> accumulator) {
		accumulator.add(value);
		return accumulator;
	}

	@Override
	public Double getResult(List<InputIoTMessage> accumulator) {
		Double result = 0.0;
		for (InputIoTMessage msg : accumulator) {
			result += Double.valueOf(msg.getData1());
		}
		return result / accumulator.size();
	}

	@Override
	public List<InputIoTMessage> merge(List<InputIoTMessage> a, List<InputIoTMessage> b) {
		a.addAll(b);
		return a;
	}

}
