package com.baeldung.flink.connector;

import com.baeldung.flink.model.InputIoTMessage;
import com.baeldung.flink.model.InputMessage;
import com.baeldung.flink.schema.InputMessageDeserializationSchema;
import com.baeldung.flink.schema.IoTMessageDeserializationSchema;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;

public class Consumers {

    public static FlinkKafkaConsumer<String> createStringConsumerForTopic(String topic, String kafkaAddress, String kafkaGroup) {
        Properties props = new Properties();
        props.setProperty("bootstrap.servers", kafkaAddress);
        props.setProperty("group.id", kafkaGroup);
        FlinkKafkaConsumer<String> consumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), props);

        return consumer;
    }
    
    public static FlinkKafkaConsumer<InputIoTMessage> createIoTConsumerForTopic(String topic, String kafkaAddress, String kafkaGroup) {
        Properties props = new Properties();
        props.setProperty("bootstrap.servers", kafkaAddress);
        props.setProperty("group.id", kafkaGroup);
        FlinkKafkaConsumer<InputIoTMessage> consumer = new FlinkKafkaConsumer<InputIoTMessage>(topic, new IoTMessageDeserializationSchema(), props);

        return consumer;
    }
    
	/*
	 * public static FlinkKafkaConsumer011<ObjectNode>
	 * createObjectConsumerForTopic(String topic, String kafkaAddress, String
	 * kafkaGroup) { Properties props = new Properties();
	 * props.setProperty("bootstrap.servers", kafkaAddress);
	 * props.setProperty("group.id", kafkaGroup); FlinkKafkaConsumer011<ObjectNode>
	 * consumer = new FlinkKafkaConsumer011<>(topic, new SimpleStringSchema(),
	 * props);
	 * 
	 * ObjectNode objectNode; try { objectNode = mapper.readValue(message,
	 * InputIoTMessage.class); } catch (Exception e) { ObjectMapper errorMapper =
	 * new ObjectMapper(); ObjectNode errorObjectNode =
	 * errorMapper.createObjectNode(); errorObjectNode.put("jsonParseError", new
	 * String(message)); objectNode = errorObjectNode; } return objectNode;
	 * 
	 * return consumer; }
	 */

    public static FlinkKafkaConsumer<InputMessage> createInputMessageConsumer(String topic, String kafkaAddress, String kafkaGroup) {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", kafkaAddress);
        properties.setProperty("group.id", kafkaGroup);
        FlinkKafkaConsumer<InputMessage> consumer = new FlinkKafkaConsumer<InputMessage>(topic, new InputMessageDeserializationSchema(), properties);

        return consumer;
    }
    
    public static FlinkKafkaConsumer<InputIoTMessage> createInputIoTMessageConsumer(String topic, String kafkaAddress, String kafkaGroup) {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", kafkaAddress);
        properties.setProperty("group.id", kafkaGroup);
        FlinkKafkaConsumer<InputIoTMessage> consumer = new FlinkKafkaConsumer<InputIoTMessage>(topic, new IoTMessageDeserializationSchema(), properties);

        return consumer;
    }
}
