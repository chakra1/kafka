package com.baeldung.flink.operator;

import java.io.StringWriter;
import java.nio.charset.Charset;

import org.apache.flink.api.common.functions.MapFunction;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.baeldung.flink.model.InputIoTMessage;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectMapper.*;

public class IoTMessageParser implements MapFunction<String, String> {

	@Override
	public String map(String value) throws Exception {
		
		System.out.println("Message value read from topic : " + value);
		byte[] jsonData = value.getBytes(Charset.forName("UTF-8"));
		//create ObjectMapper instance
				ObjectMapper objectMapper = new ObjectMapper();
				
				//convert json string to object
				InputIoTMessage iotMsg = objectMapper.readValue(jsonData, InputIoTMessage.class);
				
//				System.out.println("IOT Message\n"+iotMsg);
				
				//convert Object to json string
				InputIoTMessage iotJson = createIoTMessage(
						iotMsg.getUserId(),
						iotMsg.getDeviceId(),
						iotMsg.getName(),
						iotMsg.getData1(),
						iotMsg.getNdata1(),
						iotMsg.getTimestamp());
				//configure Object mapper for pretty print
				//objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
				
				//writing to console, can write to any output stream such as file
				/*
				 * StringWriter stringIoT = new StringWriter();
				 * objectMapper.writeValue(stringIoT, iotJson);
				 * System.out.println("IoT Message JSON is\n"+stringIoT);
				 */
				return value;

	}
	
	public static InputIoTMessage createIoTMessage(String userId, String devicId, String name,
			String data1, Double ndata1, Long timestamp) throws Exception {

			InputIoTMessage msg = new InputIoTMessage();
			msg.setUserId(userId);
			msg.setDeviceId(devicId);
			msg.setName(name);
			msg.setData1(data1);
			msg.setNdata1(ndata1);
			msg.setTimestamp(timestamp);
			return msg;
		
	}

}
