package com.baeldung.flink.model;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.google.common.base.Objects;

import java.time.LocalDateTime;


@JsonSerialize
public class InputIoTMessage {
    String userId;
    String deviceId;
    String name;
    String data1;
    Double ndata1;
    Long timestamp;

    public InputIoTMessage() {
    }

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getData1() {
		return data1;
	}

	public void setData1(String data1) {
		this.data1 = data1;
	}

	public Double getNdata1() {
		return ndata1;
	}

	public void setNdata1(Double ndata1) {
		this.ndata1 = ndata1;
	}

	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public int hashCode() {
		return java.util.Objects.hash(data1, deviceId, name, ndata1, timestamp, userId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InputIoTMessage other = (InputIoTMessage) obj;
		return java.util.Objects.equals(data1, other.data1) && java.util.Objects.equals(deviceId, other.deviceId)
				&& java.util.Objects.equals(name, other.name) && java.util.Objects.equals(ndata1, other.ndata1)
				&& java.util.Objects.equals(timestamp, other.timestamp)
				&& java.util.Objects.equals(userId, other.userId);
	}

	public InputIoTMessage(String userId, String deviceId, String name, String data1, Double ndata1, Long timestamp) {
		super();
		this.userId = userId;
		this.deviceId = deviceId;
		this.name = name;
		this.data1 = data1;
		this.ndata1 = ndata1;
		this.timestamp = timestamp;
	}

	public boolean has(String fieldName) {
		boolean isExists;
		try {
			isExists = fieldName.equalsIgnoreCase(this.getClass().getField(fieldName).getName());
		} catch (NoSuchFieldException | SecurityException e) {
			Field[] fieldArr = this.getClass().getDeclaredFields();
					
            ObjectMapper errorMapper = new ObjectMapper();
            ObjectNode errorObjectNode = errorMapper.createObjectNode();
            errorObjectNode.put("jsonParseError", new String(message));
            objectNode = errorObjectNode;
			return false;
		}
		return true;
	}


}
