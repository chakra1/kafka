package com.baeldung.flink;

import static com.baeldung.flink.connector.Consumers.createInputMessageConsumer;
import static com.baeldung.flink.connector.Consumers.createStringConsumerForTopic;
import static com.baeldung.flink.connector.Consumers.createIoTConsumerForTopic;
import static com.baeldung.flink.connector.Producers.createBackupProducer;
import static com.baeldung.flink.connector.Producers.createStringProducer;

import java.nio.charset.Charset;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessAllWindowFunction;
import org.apache.flink.streaming.api.functions.windowing.ProcessAllWindowFunction.Context;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.baeldung.flink.model.Backup;
import com.baeldung.flink.model.InputIoTMessage;
import com.baeldung.flink.model.InputMessage;
import com.baeldung.flink.operator.AverageAggregator;
import com.baeldung.flink.operator.BackupAggregator;
import com.baeldung.flink.operator.InputMessageTimestampAssigner;
import com.baeldung.flink.operator.IoTMessageParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class FlinkTumblingWindowPipeline {
	
	private static final Logger LOG = 
			LoggerFactory.getLogger(FlinkTumblingWindowPipeline.class);

    public static void average() throws Exception {
        String inputTopic = "sensors1";
        String outputTopic = "sensors_out";
        String consumerGroup = "testconsumer1";
        String address = "kafka:9092"; //localhost

        StreamExecutionEnvironment environment = StreamExecutionEnvironment.getExecutionEnvironment();

        FlinkKafkaConsumer011<InputIoTMessage> flinkKafkaConsumer = createIoTConsumerForTopic(inputTopic, address, consumerGroup);
        flinkKafkaConsumer.setStartFromEarliest();
        

        DataStream<InputIoTMessage> stringInputStream = environment.addSource(flinkKafkaConsumer);
        System.out.println("IoT Message received :: " );
        
        
        stringInputStream
        .filter((event) -> {
            if( event.getJsonParseError()!="") { //event.has("jsonParseError") &&
                LOG.warn("JsonParseException was handled: " + event.getJsonParseError());
                return false;
            }
            return true;
        })
        .filter(new FilterFunction<InputIoTMessage>() {
			private static final long serialVersionUID = 1L;
			@Override
			public boolean filter(InputIoTMessage value) throws Exception {
				System.out.println("IoT Message = " + value);
				if(value.getName().equalsIgnoreCase("gps/speed"))
					return true;
				return false;
			}    	
        })
        .timeWindowAll(Time.minutes(1))
        .aggregate(new AverageAggregator())
        .print();
        
		/*
		 * FlinkKafkaProducer011<String> flinkKafkaProducer =
		 * createStringProducer(outputTopic, address);
		 * 
		 * stringInputStream.map(new IoTMessageParser()) .addSink(flinkKafkaProducer);
		 */

        environment.execute();
    }
    
    public static void main(String[] args) throws Exception {
        //createBackup();
        average();
    }
    

   }
