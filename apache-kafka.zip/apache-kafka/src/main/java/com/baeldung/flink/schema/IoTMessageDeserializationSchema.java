package com.baeldung.flink.schema;

import com.baeldung.flink.model.InputIoTMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class IoTMessageDeserializationSchema implements DeserializationSchema<InputIoTMessage> {

	private ObjectMapper mapper;
	@Override
	public TypeInformation<InputIoTMessage> getProducedType() {
		return TypeInformation.of(InputIoTMessage.class);
	}

	@Override
	public InputIoTMessage deserialize(byte[] message) throws IOException, JsonProcessingException, JsonMappingException {
        if (mapper == null) {
            mapper = new ObjectMapper();
        }
        InputIoTMessage iotMsg;
        try {
        	iotMsg = mapper.readValue(message, InputIoTMessage.class);
        } catch (Exception e) {
        	iotMsg = new InputIoTMessage();
        	iotMsg.setJsonParseError(e.getMessage());
        }
         
        return iotMsg;
	}

	@Override
	public boolean isEndOfStream(InputIoTMessage nextElement) {
		return false;
	}
	
}
