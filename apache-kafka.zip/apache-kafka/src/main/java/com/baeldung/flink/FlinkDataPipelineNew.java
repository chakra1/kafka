package com.baeldung.flink;

import static com.baeldung.flink.connector.Consumers.createInputMessageConsumer;
import static com.baeldung.flink.connector.Consumers.createStringConsumerForTopic;
import static com.baeldung.flink.connector.Consumers.createIoTConsumerForTopic;
import static com.baeldung.flink.connector.Producers.createBackupProducer;
import static com.baeldung.flink.connector.Producers.createStringProducer;

import java.nio.charset.Charset;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer011;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer011;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.baeldung.flink.model.Backup;
import com.baeldung.flink.model.InputIoTMessage;
import com.baeldung.flink.model.InputMessage;
import com.baeldung.flink.operator.BackupAggregator;
import com.baeldung.flink.operator.InputMessageTimestampAssigner;
import com.baeldung.flink.operator.IoTMessageParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class FlinkDataPipelineNew {
	
	private static final Logger LOG = 
			LoggerFactory.getLogger(FlinkDataPipelineNew.class);

    public static void format() throws Exception {
        String inputTopic = "sensors";
        String outputTopic = "sensors_out";
        String consumerGroup = "baeldung";
        String address = "kafka:9092"; //localhost

        StreamExecutionEnvironment environment = StreamExecutionEnvironment.getExecutionEnvironment();

        FlinkKafkaConsumer011<InputIoTMessage> flinkKafkaConsumer = createIoTConsumerForTopic(inputTopic, address, consumerGroup);
        flinkKafkaConsumer.setStartFromEarliest();
        

        DataStream<InputIoTMessage> stringInputStream = environment.addSource(flinkKafkaConsumer);
        System.out.println("IoT Message received :: " );
        
        
        stringInputStream
        .filter((event) -> {
            if( event.getJsonParseError()!="") { //event.has("jsonParseError") &&
                LOG.warn("JsonParseException was handled: " + event.getJsonParseError());
                return false;
            }
            return true;
        })
        .print();
        
		/*
		 * FlinkKafkaProducer011<String> flinkKafkaProducer =
		 * createStringProducer(outputTopic, address);
		 * 
		 * stringInputStream.map(new IoTMessageParser()) .addSink(flinkKafkaProducer);
		 */

        environment.execute();
    }
    
    public static void main(String[] args) throws Exception {
        //createBackup();
        format();
    }

   }
